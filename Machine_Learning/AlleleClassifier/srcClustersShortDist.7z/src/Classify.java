import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class Classify
{

	public static void main(String[] args)
	{
		String testsFolder = "C:/Users/zhouDev.ZBCORP/Downloads/tc/";
		Boolean developeMode = true;
		if (developeMode)
		{
			String fileIn = "TrainingData.csv";
			// ClassifierHelper h = new ClassifierHelper();
			// h.seperate(fileIn);
			try
			{
				List<String> all = Files.readAllLines(Paths.get(testsFolder + fileIn), Charset.forName("ISO-8859-1"));
				int toIndex = (int) (all.size() * 0.65);
				// String[] trains = all.toArray(new String[0]);
				String[] trains = all.subList(0, toIndex).toArray(new String[0]);
				String[] tests = all.subList(toIndex, all.size() - 1).toArray(new String[0]);
				AlleleClassifier c = new AlleleClassifier();
				String[] results = c.classify(trains, tests, null);
				int correct = 0;
				for (int i = 0; i < results.length; ++i)
				{
					if (results[i].equals(tests[i]))
						++correct;
//					else
//					{
//						if (i < 25)
//							System.out.println("\tActual: " + tests[i] + "\tResult: " + results[i]);
//					}
				}
				System.out.println(correct + " out of " + results.length + "(" + (double) correct / results.length
						* 100 + ") correct!");
				System.out.println(c.getTraningReport());
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			String[][] testFiles = {
					{ "DataExample0Train.csv", "DataExample0Tests.csv", "DataExample0GroundTruth.csv" },
					{ "DataExample1Train.csv", "DataExample1Tests.csv", "DataExample1GroundTruth.csv" },
					{ "DataExample2Train.csv", "DataExample2Tests.csv", "DataExample2GroundTruth.csv" },
					{ "DataExample3Train.csv", "DataExample3Tests.csv", "DataExample2GroundTruth.csv" },
					{ "DataExample4Train.csv", "DataExample4Tests.csv", "DataExample4GroundTruth.csv" } };

			try
			{
				for (int j = 0; j < 1; ++j)
				{
					String[] trains = Files.readAllLines(Paths.get(testsFolder + testFiles[j][0]),
							Charset.forName("ISO-8859-1")).toArray(new String[0]);
					String[] tests = Files.readAllLines(Paths.get(testsFolder + testFiles[j][1]),
							Charset.forName("ISO-8859-1")).toArray(new String[0]);
					String[] truths = Files.readAllLines(Paths.get(testsFolder + testFiles[j][2]),
							Charset.forName("ISO-8859-1")).toArray(new String[0]);
					AlleleClassifier c = new AlleleClassifier();
					String[] results = c.classify(trains, tests, truths);
					int correct = 0;
					for (int i = 0; i < results.length; ++i)
					{
						if (results[i].equals(tests[i] + ',' + truths[i]))
							++correct;
						else
						{
							if (i < 28)
								System.out.println("\t#" + i + " Actual: " + tests[i] + ',' + truths[i] + "\tResult: "
										+ results[i]);
						}
					}
					System.out.println(correct + " out of " + results.length + "(" + (double) correct / results.length
							* 100 + ") correct!");
					System.out.println(c.getTraningReport());
				}
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		// System.out.println("Type any key to terminate:\n>>");
		// System.in.read();
		System.out.println("Done");
	}
}
