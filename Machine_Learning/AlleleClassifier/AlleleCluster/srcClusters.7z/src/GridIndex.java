public final class GridIndex implements Comparable<Object>
{
	public int mX = -1;
	public int mY = -1;
	public int mZ = -1;

	GridIndex(int[] idx)
	{
		mX = idx[0];
		mY = idx[1];
		mZ = idx[2];
	}
	
	
	@Override
	public String toString()
	{
		return "(" + mX + ',' + mY + ',' + mZ + ')';
	}

	@Override
	public int compareTo(Object otherObject)
	{
		GridIndex other = (GridIndex) otherObject;
		if (mX < other.mX)
			return -1;
		if (mX > other.mX)
			return 1;

		if (mY < other.mY)
			return -1;
		if (mY > other.mY)
			return 1;

		if (mZ < other.mZ)
			return -1;
		if (mZ > other.mZ)
			return 1;
		
		return 0;
	}

}
