//import java.io.IOException;

public final class AlleleClassifier
{
	public final static int COLOR1 = 0;
	public final static int COLOR1OR2 = COLOR1 + 1; // 1
	public final static int COLOR2 = COLOR1OR2 + 1; // 2
	public final static int COLOR0 = COLOR2 + 1; // 3
	public final static int COLOR0OR1 = COLOR0 + 1; // 4
	public final static int COLOROVER2 = COLOR0OR1 + 1; // 5
	public final static int NUMCOLORS = COLOROVER2 + 1;
	public final static String[] s_colors = { "1", "1 or 2", "2", "0", "0 or 1", ">2" };

	private final static double gridGranularity = 350;
	private final static double rangeScaleFactor = 0.01;
	// band
	private final static int bufferSize = 1000;
	private EntryCB buffer = new EntryCB(bufferSize);
	private Grid clusters = null;
	private final double BIG = 1e10;
	private double[] clusterRanges = { BIG, -BIG, BIG, -BIG, BIG, -BIG };

	public String[] classify(String[] trains, String[] tests, String[] truths)
	{
		System.out.println("total trains: " + trains.length + "; total tests: " + tests.length);
		train(trains);

		return classify(tests, truths);
	}

	private void train(String[] entries)
	{
		int numBuffered = 0;
		for (String entry : entries)
		{
			++numBuffered;
			Entry me = createEntry(entry);
			if (clusters != null)
			{
				int[] loc = clusters.feedOneSample(me);
				me.dims = loc;
			}
			Entry old = buffer.add(me);
			if (old != null)
			{
				if (null == clusters)
					System.out.println("Can't be here"); // TODO: implementation
															// error exception
				else
					clusters.disposeOneSample(old);
			}
			if (numBuffered == bufferSize && null == clusters)
			{
				buildCluster();
				// System.out.println("Paused, Type any key to continue:\n>>");
				// try
				// {
				// System.in.read();
				// }
				// catch (IOException e)
				// {
				// e.printStackTrace();
				// }
			}
		}
		System.out.print("Ranges final: ");
		for (int i = 0; i < Grid.NUMDIMS; ++i)
			System.out.print("(" + clusterRanges[2 * i] + "," + clusterRanges[2 * i + 1] + ") ");
		System.out.println("");
		if (null == clusters)
		{
			buildCluster();
		}
		clusters.analyzeQuality();
	}

	private Entry createEntry(String entry)
	{
		Entry me = new Entry();
		String[] strs = entry.split(",");
		me.bID = Integer.parseInt(strs[0]);
		me.sID = Integer.parseInt(strs[1]);
		me.x = Double.parseDouble(strs[2]);
		me.y = Double.parseDouble(strs[3]);
		me.z = me.x - me.y;
		if (me.x < clusterRanges[0])
			clusterRanges[0] = me.x;
		if (me.x > clusterRanges[1])
			clusterRanges[1] = me.x;
		if (me.y < clusterRanges[2])
			clusterRanges[2] = me.y;
		if (me.y > clusterRanges[3])
			clusterRanges[3] = me.y;
		if (me.z < clusterRanges[4])
			clusterRanges[4] = me.z;
		if (me.z > clusterRanges[5])
			clusterRanges[5] = me.z;

		if (strs.length == 5)
			for (int i = 0; i < s_colors.length; ++i)
			{
				if (s_colors[i].equals(strs[4]))
				{
					me.color = i;
					break;
				}
			}

		return me;
	}

	private void buildCluster()
	{
		System.out.print("Build cluster: ");
		for (int i = 0; i < Grid.NUMDIMS; ++i)
			System.out.print("(" + clusterRanges[2 * i] + "," + clusterRanges[2 * i + 1] + ") ");
		System.out.println("");
		clusters = new Grid();
		for (int i = 0; i < 3; ++i)
		{
			double granule = clusterRanges[2 * i + 1] - clusterRanges[2 * i];
			double gard = granule * rangeScaleFactor / 2;
			double tmp1 = clusterRanges[2 * i] - gard;
			double tmp2 = clusterRanges[2 * i + 1] + gard;
			clusters.setRange(i, tmp1, tmp2);
			granule = granule / gridGranularity;
			clusters.setGranularity(i, granule);
		}
		clusters.buildGrid();
		int[] clustersDim = clusters.getGridDimension();
		System.out.println("Cluster dim: " + clustersDim[0] + "," + clustersDim[1] + ", " + clustersDim[2]);
		Entry[] rawBuf = buffer.getBuffer();
		for (int i = 0; i < rawBuf.length; ++i)
		{
			if (rawBuf[i] == null)
				break;
			clusters.feedOneSample(rawBuf[i]);
		}
	}

	public String getTraningReport()
	{
		double multi = clusters.getMultiHitsRate();
		double collid = clusters.getCollisionRate();
		int outliers = clusters.getOutliers().size();

		return clusters.numberofCellsOccupied() + " cells occupied; " + "multi-hit rate: " + multi * 100
				+ "; collision rate: " + collid * 100 + "; multi-hits with collision rate: "
				+ clusters.getMultiHitsWithCollisionRate() * 100 + "; " + outliers + " outliers";
	}

	private String[] classify(String[] entries, String[] truths)
	{
		String[] results = new String[entries.length];

		for (int i = 0; i < entries.length; ++i)
		{
			String str = entries[i];
			if (truths != null)
				str = str + ',' + truths[i];
			Entry me = createEntry(str);
//			int currentIdx = clusters.junkVacummeCorrect;
			clusters.resloveColor(me, i);
			String color = "";
			if (me.color >= 0)
				color = s_colors[me.color];
			results[i] = str.substring(0, str.lastIndexOf(',')) + ',' + color;
//			int idxNow = clusters.junkVacummeCorrect;
//			if (idxNow > currentIdx)
//			{
//				if (!results[i].equals(entries[i]))
//					System.out.println("Actual: " + entries[i] + "; resolved: " + results[i] + " with color: " + me.color);
//			}
		}
		System.out.println(clusters.junkOutofRange + " out of range " + clusters.junkOutofRangeCorrect + " correct, "
				+ clusters.junkVacumme + " in vacuum " + clusters.junkVacummeCorrect + " correct, "
				+ clusters.junkCollision + " unresolved collisions contains: " + clusters.junkCollisionLow
				+ " lows and " + clusters.junkCollisionHigh + " highs; " + "resolved collisions: "
				+ clusters.junkCollisionResolved + " with " + clusters.junkCollisionResolvedCorrect
				+ " correct; directly resolved: " + clusters.junkResolved + " with " + clusters.junkResolvedCorrect
				+ " correct");
		return results;
	}
}
