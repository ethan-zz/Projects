
public class Entry
{
	public int bID = -1; // batch ID
	public int sID = -1; // sampleID
	public double x = 0;
	public double y = 0;
	public double z = 0;
	public int color = -1;
	public int bufloc = -1; // location in circular buffer
	public int[] dims = null;
}
