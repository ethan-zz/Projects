import java.util.LinkedList;
import java.util.List;


public class Cell
{
	public int[] colorsHit = {0, 0, 0, 0, 0, 0};
	public Boolean collision = false;
	public Boolean multiHit = false;
	public List<Entry> entries = new LinkedList<Entry>();
	public int[] loc = null;
}
