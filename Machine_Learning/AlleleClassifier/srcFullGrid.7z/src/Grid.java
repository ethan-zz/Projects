import java.util.LinkedList;
import java.util.List;

//import org.w3c.dom.ranges.RangeException;

public class Grid
{
	public static final int XDIM = 0;
	public static final int YDIM = XDIM + 1;
	public static final int ZDIM = YDIM + 1;
	public static final int NUMDIMS = ZDIM + 1;

	private double[] ranges = { 0, 0, 0, 0, 0, 0 };
	private double[] granules = { 1, 1, 1 };
	private Cell[][][] cells = null;
	private int[] gridDims = { 0, 0, 0 };
	private int cellsOccupied = 0;
	private int cellsCollided = 0;
	private int cellsMultiHits = 0;
	private int cellsMultiHitsWithCollision = 0;
	private List<Entry> outliers = new LinkedList<Entry>();
	private int[] buckets = { 0, 0, 0, 0, 0, 0 };
	private List<Cell> alls = new LinkedList<Cell>();
	private double g = 1.0;
	private Boolean doPrintout = true;

	public int junkOutofRange = 0;
	public int junkOutofRangeCorrect = 0;
	public int junkVacumme = 0;
	public int junkVacummeCorrect = 0;
	public int junkCollision = 0;
	public int junkCollisionHigh = 0;
	public int junkCollisionLow = 0;
	public int junkCollisionResolved = 0;
	public int junkCollisionResolvedCorrect = 0;
	public int junkResolved = 0;
	public int junkResolvedCorrect = 0;

	public void reqestDoPrintout(Boolean r)
	{
		doPrintout = r;
	}

	public void setRange(int which, double low, double high)
	{
		// TODO: convert to exception
		if (which < 0 || which > 2 || low >= high)
			return;
		ranges[which * 2] = low;
		ranges[which * 2 + 1] = high;
		cells = null;
		outliers.clear();
	}

	public void setGranularity(int which, double granule)
	{
		if (which < 0 || which > 2 || granule <= 0)
			return;
		granules[which] = granule;
		cells = null;
		outliers.clear();
	}

	public int[] getGridDimension()
	{
		return gridDims;
	}

	public void buildGrid()
	{
		if (cells == null)
		{
			for (int i = 0; i < NUMDIMS; ++i)
				gridDims[i] = (int) (Math.ceil((ranges[2 * i + 1] - ranges[2 * i]) / granules[i]));
			if (doPrintout)
			{
				int totalCells = 1;
				System.out.print("Ranges in use: ");
				for (int i = 0; i < NUMDIMS; ++i)
				{
					System.out.print("(" + ranges[2 * i] + "," + ranges[2 * i + 1] + " : " + gridDims[i] + ") ");
					totalCells *= gridDims[i];
				}
				System.out.println("");
				System.out.println("Total cells: " + totalCells);
			}
			cells = new Cell[gridDims[XDIM]][gridDims[YDIM]][gridDims[ZDIM]];
		}
	}

	public int[] feedOneSample(Entry item)
	{
		int[] dims = getEntryCell(item);
		if (dims != null)
		{
			Cell me = cells[dims[XDIM]][dims[YDIM]][dims[ZDIM]];
			if (me == null)
			{
				me = new Cell();
				cells[dims[XDIM]][dims[YDIM]][dims[ZDIM]] = me;
				me.loc = dims;
				++cellsOccupied;
				alls.add(me);
			}
			else
			{
				// Already exist (i.e. colored), now hit with a different color,
				// need analysis to decide if we need to make our grid finer.
				if (me.colorsHit[item.color] == 0)
					me.collision = true;
				else
					me.multiHit = true;
			}
			++(me.colorsHit[item.color]);
			me.entries.add(item);
			++(buckets[item.color]);
		}
		return dims;
	}

	private int[] getEntryCell(Entry item)
	{
		if (!entryInRange(item))
		{
			outliers.add(item);
			return null;
		}

		int[] dims = { 0, 0, 0 };
		dims[XDIM] = (int) (Math.ceil((item.x - ranges[0]) / granules[XDIM]));
		dims[YDIM] = (int) (Math.ceil((item.y - ranges[2]) / granules[YDIM]));
		dims[ZDIM] = (int) (Math.ceil((item.z - ranges[4]) / granules[ZDIM]));
		return dims;
	}

	public void disposeOneSample(Entry item)
	{
		if (item.dims != null)
		{
			Cell owner = cells[item.dims[XDIM]][item.dims[YDIM]][item.dims[ZDIM]];
			if (owner.entries.contains(item))
				owner.entries.remove(item);
			else
			{
				// TODO Should not be here. Implementation error exception.
				System.out.println("Implementation error: " + item.dims[XDIM] + ", " + item.dims[YDIM] + ","
						+ item.dims[ZDIM]);
			}
		}
	}

	public void analyzeQuality()
	{
		int occupied = 0;

		cellsCollided = 0;
		cellsMultiHits = 0;
		for (int i = 0; i < gridDims[XDIM]; ++i)
		{
			for (int j = 0; j < gridDims[YDIM]; ++j)
				for (int k = 0; k < gridDims[ZDIM]; ++k)
				{
					Cell me = cells[i][j][k];
					if (me != null)
					{
						++occupied;
						if (me.collision)
							++cellsCollided;
						if (me.multiHit)
							++cellsMultiHits;
						if (me.collision && me.multiHit)
							++cellsMultiHitsWithCollision;
					}
				}
		}
		if (doPrintout)
		{
			// TODO: generating error/warning
			System.out.println("Cell in use accumulated: " + cellsOccupied + " verified: " + occupied);
			int totals = 0;
			for (int i = 0; i < AlleleClassifier.NUMCOLORS; ++i)
				totals += buckets[i];
			System.out.print("Buckets(" + totals + "): ");
			for (int i = 0; i < AlleleClassifier.NUMCOLORS; ++i)
				System.out.print("(" + AlleleClassifier.s_colors[i] + "," + buckets[i] + ") ");
			System.out.println("");

			System.out.println("Cells occupied: " + cellsOccupied + "; multi-hit: " + cellsMultiHits
					+ "; in collision: " + cellsCollided + "; multi-hit & collision: " + cellsMultiHitsWithCollision);
		}

	}

	private Boolean entryInRange(Entry i)
	{
		return (i.x > ranges[0] && i.x < ranges[1]) && (i.y > ranges[2] && i.y < ranges[3])
				&& (i.z > ranges[4] && i.z < ranges[5]);
	}

	public List<Entry> getOutliers()
	{
		return outliers;
	}

	public int numberofCellsOccupied()
	{
		return cellsOccupied;
	}

	public double getOccupiedRate()
	{
		return (double) (gridDims[XDIM] * gridDims[YDIM] * gridDims[ZDIM]) / (double) cellsOccupied;
	}

	public double getMultiHitsRate()
	{
		return (double) cellsMultiHits / (double) cellsOccupied;
	}

	public double getCollisionRate()
	{
		return (double) cellsCollided / (double) cellsOccupied;
	}

	public double getMultiHitsWithCollisionRate()
	{
		return (double) (cellsMultiHitsWithCollision) / (double) cellsOccupied;
	}

	public void resloveColor(Entry item, int index)
	{
		int[] dims = getEntryCell(item);
		if (dims != null)
		{
			Cell me = cells[dims[XDIM]][dims[YDIM]][dims[ZDIM]];
			if (me != null)
			{
				int color = -1; // junk value
				int hits = 0;
				Boolean directHit = false;
				Boolean collisionHigh = false;
				Boolean collisionLow = false;
				if (!me.collision)
					directHit = true;
				for (int i = 0; i < AlleleClassifier.NUMCOLORS; ++i)
				{
					if (me.colorsHit[i] > hits)
					{
						hits = me.colorsHit[i];
						color = i;
					}
					else if (me.colorsHit[i] == hits)
					{
						if (i > AlleleClassifier.COLOR2 && item.color <= AlleleClassifier.COLOR2)
							color = i;
						else
						{
							if (i > AlleleClassifier.COLOR2 && item.color > AlleleClassifier.COLOR2)
								collisionHigh = true;
							if (i <= AlleleClassifier.COLOR2 && item.color <= AlleleClassifier.COLOR2)
								collisionLow = true;
						}
					}
				}
				if (directHit)
				{
					++junkResolved;
					if (item.color == color)
						++junkResolvedCorrect;
//					else
//					{
//						System.out.print("#" + index + "actual: " + AlleleClassifier.s_colors[item.color]
//								+ "; resolved: " + AlleleClassifier.s_colors[color] + ". " + "Multi-Hits("
//								+ me.multiHit + "): ");
//						for (int i = 0; i < AlleleClassifier.NUMCOLORS; ++i)
//							System.out.print(AlleleClassifier.s_colors[i] + "=" + me.colorsHit[i] + "; ");
//						System.out.println("");
//					}
				}
				else
				{
					if (color >= 0)
					{
						++junkCollisionResolved;
						if (item.color == color)
							++junkCollisionResolvedCorrect;
					}
					else
					{
						++junkCollision;
						if (collisionHigh)
							++junkCollisionHigh;
						if (collisionLow)
							++junkCollisionLow;
					}
				}

				item.color = color;
			}
			else
			{
				int actual = item.color;
				resolveVaccume(item);
				++junkVacumme;
				if( actual == item.color)
					++junkVacummeCorrect;
			}
		}
		else
		{
			int actual = item.color;
			resolveVaccume(item);
			++junkOutofRange;
			if(actual == item.color)
			++junkOutofRangeCorrect;
		}
	}

	private void resolveVaccume(Entry item)
	{
		double[] gravities = { 0, 0, 0, 0, 0, 0 };
		for (Cell me : alls)
		{
			double x = ranges[2 * XDIM] + (me.loc[XDIM] + 0.5) * granules[XDIM];
			double y = ranges[2 * YDIM] + (me.loc[YDIM] + 0.5) * granules[YDIM];
			double z = ranges[2 * ZDIM] + (me.loc[ZDIM] + 0.5) * granules[ZDIM];

			double d = Math.pow((item.x - x), 2) + Math.pow((item.y - y), 2) + Math.pow((item.z - z), 2);
			for (int i = 0; i < AlleleClassifier.NUMCOLORS; ++i)
			{
				if (me.colorsHit[i] > 0)
					gravities[i] += g / d;
			}
		}
		int max = 0;
		for (int i = 1; i < AlleleClassifier.NUMCOLORS; ++i)
		{
			if(gravities[i] > gravities[max])
				max = i;
		}

		item.color = max;
	}
}
