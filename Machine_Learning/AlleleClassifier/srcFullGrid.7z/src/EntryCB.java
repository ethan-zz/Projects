// Circular buffer for Entry
class EntryCB
{
	private Entry[] buf = null;
	private int tail = 0;
	public EntryCB(int size)
	{
		buf = new Entry[size];
	}
	
	// Returns the Entry that is kicked out of this buffer
	public Entry add(Entry item)
	{
		int loc = tail % buf.length;
		Entry tmp = buf[loc];
		buf[loc] = item;
		item.bufloc = loc;
		++tail;
		return tmp;
	}
	
	public Entry[] getBuffer()
	{
		return buf;
	}
}
