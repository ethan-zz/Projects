import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

	
public class Classify
{

	public static void main(String[] args)
	{
		String fileIn = "C:/Users/zhouDev.ZBCORP/Downloads/tc/TrainingData.csv";
		// ClassifierHelper h = new ClassifierHelper();
		// h.seperate(fileIn);
		try
		{
			List<String> all = Files.readAllLines(Paths.get(fileIn), Charset.forName("ISO-8859-1"));
			int toIndex = (int)(all.size()*0.65);
//			String[] trains = all.toArray(new String[0]);
			String[] trains = all.subList(0, toIndex).toArray(new String[0]);
			String[] tests = all.subList(toIndex, all.size()-1).toArray(new String[0]);
			AlleleClassifier c = new AlleleClassifier();
			String[] results = c.classify(trains, tests);
			int correct = 0;
			for(int i = 0; i < results.length; ++i)
			{
				if(results[i].equals(tests[i]))
					++correct;
//				else
//					System.out.println("\tActual: " + tests[i] + "\n\tResult: " + results[i]);
			}
			System.out.println( correct + " out of " + results.length + "(" + (double)correct/results.length *100 + ") correct!");
			System.out.println(c.getTraningReport());
//			System.out.println("Type any key to terminate:\n>>");
//			System.in.read();
			System.out.println("Done");
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
	}
}
